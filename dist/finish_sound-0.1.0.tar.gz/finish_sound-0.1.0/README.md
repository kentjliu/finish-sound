# finish-sound

`finish-sound` is a simple, silly Python package that plays a sound when your code finishes executing.

## Installation

You can install the package via `pip`:
```
pip install finish-sound
```

